#ifndef __UTIL_H__
#define __UTIL_H__

char *get_resolvconf_addr();
void socket_setrtable(int fd, int rtable);

#endif
